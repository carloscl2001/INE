@extends('templates.master')
@section('content-center')
@if(session()->has('success'))
 <div class="alert alert-success">
 {{ session()->get('success', null)[0] }}
 </div>
 @endif
 
 @foreach ($errors->all() as $sError)
 <div class="alert alert-warning">{{ $sError }}</div>
 @endforeach
 <div class="card">
 <div class="card-header text-center font-weight-bold">
 Datos de usuario
 </div>
 <div class="card-body">
 <form name="edit-user-form" id="edit-user-form" 
 action="{{ route('product.update', ['product' => $product]) }}" method="post">
 @method('PATCH')
 @csrf
 <br/>
 <label for="name">{{ __('auth.Name') }}</label>
 <input type="text" id="name" name="name" 
 class="form-control" required="" 
 value="{{ Auth::user()->name }}" />

 <label for="company_id">{{ __('auth.Company') }}</label>
 <select class="form-control" name="company_id" id="company_id" required>
 <option value="">{{ __('auth.DoSelect') }}</option> 
 @foreach($aCompany as $company)
    @if ($company->id == Auth::user()->company_id)
        <option value="{{ $company->id }}" selected >{{ $company->name }}</option>
    @else
        <option value="{{ $company->id }}">{{ $company->name }}</option>
    @endif
 @endforeach
 </select>

 </div>
 <button type="submit" class="btn btn-primary">{{ 
 __('auth.Save') }}</button>
 </form>
 </div>
 </div>


@endsection
