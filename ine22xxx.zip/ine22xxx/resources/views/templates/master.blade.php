<!doctype html>
<!-- Bootstrap first template for Internet y Negocio Electrónico, University of Cadiz,
     since 2019, based on https://www.w3schools.com/bootstrap4/bootstrap_templates.asp -->
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">      
        <link rel="stylesheet" href="/css/bootstrap.min.css"/>
        <script src="https://kit.fontawesome.com/932bba5f26.js" crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Peralta&display=swap" rel="stylesheet">
        <title>My Ine Project</title>
        <style>
            :root{
            --main-header-color:linear-gradient(45deg,#ffbc6a,#ffbc6a);
            }
            body,html{
            margin: 25px 0px 25px 10px;
            padding: 0;
            min-height: 100vh;
            background-image: url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23efefef' fill-opacity='1' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E");
            }

            header{
            height: 80px;
            padding: 10px;
            width: 100%;
            display: flex;
            background: var(--main-header-color);
            position: fixed;
            top: 0;
            left: 0;
            }

            .logo{
            width: 300px;
            justify-content: center;
            align-items: center;
            }

            .logo img{
            width: 100%;
            }
            
            .search-place{
            width: 55%;
            display: flex;
            padding: 10px 20px;
            }

            .search-place input{
            Font-family: 'Candara';
            border-radius: 10px 0px 0px 10px;
            padding: 10px;
            font-size: 18px;
            background-color: #fefefe;
            border: 1px solid #ccc;
            width: calc(100% - 62px);
            font-family: 'Peralte';
            }

            .search-place input:placeholder{
            color: #fff;
            
            }

            .btn-main{
            border-radius: 0px 10px 10px 0px;
            padding: 10px;
            width: 50px;
            font-size: 15px;
            background-color: #fff;
            border-style: none;
            border: 1px solid #ccc;
            cursor: pointer;
            }

            .btn-bsucar{
            width: 80px;
            }

            .title-section{
            font-family: 'Peralta', cursive;
            padding: 50px 0px 0px 0px;
            font-size: 40px;
            width: 100%;
            }
            .title{
            text-align: center;
            padding: 5px 5px 0px 5px;
            font-size: 18px;
            color: #999;
            width: calc(100% - 10px);

            }

            .price{
            text-align: center;
            font-size: 25px;
            color: #d86a6a;
            padding: 5px;
            width: calc(100% - 10px);
            }
            
            .product-box{
            display: flex;
            padding: 10px;
            width: calc(100%/5 - 20px);
            }

            .product-box a{
            text-decoration: none;
            }

            .product{
            border-radius: 10px;
            box-shadow: 0 0 8px 3px #ccc;
            background-color: #fff;
            }

            .product img{
            border-radius: 10px 10px 0 0;
            }

            .description{
            text-align: center;
            font-size: 14px;
            color: #999;
            padding: 0px 5px 5px 5px;
            width: calc(100% - 10);
            }

            .item-option{
            color: white;
            padding: 10px 10px;
            line-height: 30px;
            font-size: 30px;
            cursor: pointer;
            color: #fff;
            }

            .heading{
            color: gray;
            text-align: center;
            padding: 0px 0px 0px 0px;
            font-size: 20px;
            width: 80%;
            }

            .seccion{
            text-align: center;
            font-size: 14px;
            width: calc(100% - 10);
            }


        </style>

    </head>

<title>La casa del Manga</title>
<body>
    @include('layouts.header')
    @yield('content-center')
    
            

    @yield('content-right')

    @include('layouts.footer')
</body>
</html>