@extends('templates.master')
 
@section('title', 'Page Title')
 
@section('content-center')

<div class="row">
        

        <!-- BLOCK: CENTER -->
        <div class="col-sm-10"> <!-- col-sm-7 means seven out of twelve columns -->                     
        
            
            
        </div>   

    <div class="container-fluid" style="margin-top:30px">
    <div class="row">
        

        <!-- BLOCK: CENTER -->
        <div class="col-sm-10"> <!-- col-sm-7 means seven out of twelve columns -->                     
        
            
        <div class = "title-section"></div>
            
            <!-- Producto 2  -->
            <div class = "row">
                <div class="col-sm-2 card card-body" style="text-align: center">         
                @foreach(session()->get('cart')->htItem as $item)    
                <div class = "product-box">
                <a href = "./Ofertas">
                    <div class = "product">
                    <img src={{$item['imgUrl']}} width = "200" height = "300"></img>
                    <div class = "title">{{$item['name']}}</div>
                    
                    @if ($item['discountPercent'] > 0)
                            <div class = "price">{{round($item['price'] - $item['price']*($item['discountPercent']/100),2)}}€</div>
                        @else
                            <div class = "price">{{$item['price']}}$</div>
                        @endif
                    </div>    
                </a>
                </div>

                <div class="col-sm-4">
                <p>Cantidad: {{$item['quantity']}}</p>
                <a href="{{ route('cart.operate', [ 'operation' => 'add', 'product' => \App\Models\Product::find($item['id'])]) }}" class="btn btn-success">+</a>
                <a href="{{ route('cart.operate', [ 'operation' => 'remove', 'product' => \App\Models\Product::find($item['id'])]) }}" class="btn btn-danger">-</a>
                </div>
                @endforeach
                @if(isset($item))
                <p>Productos totales: {{session()->get('cart')->itotalItems}}</p>
                <p>Precio total: {{session()->get('cart')->dTotalPrice}} €</p>
                <a href=" {{ route('cart.operate', [ 'operation' => 'removeAll', 'product' => \App\Models\Product::find($item['id'])]) }}" class="btn btn-danger">Vaciar carrito</a>
                @else
                <p>El carrito está vacío</p>
                @endif
            </div>
                </div>



                
            </div>
        </div>                  
    </div>
</div>
                      

@endsection

