<?php

namespace Tests\Unit;
use App\Models\Cart;
use App\Models\Product;
use Tests\TestCase;
#use PHPUnit\Framework\TestCase;

class CartTest extends TestCase
{
    public static $cart;


    public static function InitializerCart(){
        self::$cart = new Cart();
        $product = Product::first();
        self::$cart->add($product);
        self::$cart->add($product);
        self::$cart->add($product);
    }
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function testConstructor()
    {
        $cart = new Cart;
        $this->assertTrue($cart->iTotalItems == 0);
        $this->assertTrue($cart->dTotalPrice == 0);
        $this->assertTrue($cart->htItem == []);
    }

    public function testAdd()
    {
        self::InitializerCart();
        $cart = self::$cart;
        $cart->add(Product::first());
        $this->assertTrue($cart->htItem[Product::first()->id]['quantity'] == 4);
        $this->assertTrue($cart->dTotalPrice == $cart->price*4);
        $this->assertTrue($cart->iTotalItems == 4); 
    }
    
    public function testRemove()
    {
        self::InitializerCart();
        $cart = self::$cart;
        $product = Product::first();
        $cart ->remove($product);
        $this->assertTrue($cart->htItem[$product->id]['quantity'] == 2);
        $this->assertFalse($cart->iTotalItems == 2);
        $this->assertFalse(Abs($cart->dTotalPrice - $product->precio*2) < 0.001);
    }

    public function testRemoveAll()
    {
        self::InitializerCart();
        $cart = self::$cart;
        $product = Product::first();
        $cart->removeAll($product);
        $this->assertTrue(!array_key_exists($product->id, $cart->htItem));
        $this->assertFalse($cart->dTotalPrice == 0);
        $this->assertTrue($cart->iTotalItems == 0);
    }
}
