<footer>
    <div class="jumbotron text-center" style="margin-bottom:0;background-color: #ffbc6a;padding:20px; margin:0; width:100%">
        <div class="row">
            <div class="col-sm-12 col-md-4" >     
                <div class="heading"><strong>SECCIONES</strong>

                    <div class="secciones">
                    <a href = "./Ofertas" style ="text-decoration: none; color:white">Ofertas
                    </a>
                    </div>

                    <div class="secciones">
                    <a href = "./Novedades" style ="text-decoration: none; color:white">Novedades
                    </a>
                    </div>

                    <div class="secciones">
                    <a href = "./CategoriaPopular1" style ="text-decoration: none; color:white">Categoria Popular1
                    </a>
                    </div>

                    <div class="secciones">
                    <a href = "./CategoriaPopular2" style ="text-decoration: none; color:white">Categoría Popular2
                    </a>
                </div>
            </div>       
        </div>
            <div class="col-sm-12 col-md-4" >
                <div class="heading"><strong>AYUDA</strong>
                <div class="secciones">

                <a href = "./CondicionesdeUso" style ="text-decoration: none; color:white">Condiciones de Uso
                </a>
                </div>

                <div class="secciones">
                <a href = "./Ayuda" style ="text-decoration: none; color:white">Ayuda
                </a>
                </div>

                <div class="secciones">
                <a href = "./PreguntasFrecuentes" style ="text-decoration: none; color:white">Preguntas Frecuentes
                </a>
                </div>

                <div class="secciones">
                <a href = "./VenderArticulos" style ="text-decoration: none; color:white">Vender Artículos"
                </a>
                </div>
            </div>
            </div>

            <div class="col-sm-12 col-md-4" >

                <div class="heading"><strong>SOBRE NOSOTROS</strong>
                    <div>
                    <a href = "./QuienesSomos" style ="text-decoration: none; color:white">QuienesSomos
                    </a>
                    </div>

                    <div class="secciones">
                    <a href = "./Historia" style ="text-decoration: none; color:white">Historia
                    </a>
                    </div>

                    <div class="secciones">
                    <a href = "./DondeEstamos" style ="text-decoration: none; color:white">DondeEstamos
                    </a>
                    </div>

                    <div class="secciones">
                    <a href = "./Blog" style="text-decoration: none; color:white">Blog
                    </a>
                    </div>
                
            </div>

        </div>
    </div>         





        </div>
    </div>
</footer>

<?php /**PATH C:\xampp\htdocs\ine22xxx\resources\views/layouts/footer.blade.php ENDPATH**/ ?>