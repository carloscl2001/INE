
<header>
    <div class="logo"><img src="/img/logo.png"></div>
    <div class="search-place d-flex form-inline">
        <input type="text" id="idbusqueda" placeholder="Busca tu artículo.....">
        <button class="btn-main btn-buscar"><i class="fa-solid fa-magnifying-glass"></i></button>
    </div>
    <ul class="ms-auto list-group list-group-horizontal">
        <div class="item-option" title="Carrito" >
            <a href="/cart" style="color:#fff">  
            <i class="fa-solid fa-cart-shopping"></i>
            </a>
            <span><?php echo e(session()->get('cart')->itotalItems); ?></span>
        </div> 
        
        <div class="item-option">
        <?php if(Auth::check()): ?>
          <li class="nav-item">
            <a class="nav-link" href="/user"><?php echo e((Auth::user()->name)); ?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/logout">X</a>
          </li>
          <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="/login">Identifícate</a>
          </li>
          <?php endif; ?>
        </div>
       
    </ul>
</header><?php /**PATH C:\xampp\htdocs\ine22xxx\resources\views/layouts/header.blade.php ENDPATH**/ ?>