
 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content-center'); ?>

<div class="row">
        

        <!-- BLOCK: CENTER -->
        <div class="col-sm-10"> <!-- col-sm-7 means seven out of twelve columns -->                     
        
            
            
        </div>   

    <div class="container-fluid" style="margin-top:30px">
    <div class="row">
        

        <!-- BLOCK: CENTER -->
        <div class="col-sm-10"> <!-- col-sm-7 means seven out of twelve columns -->                     
        
            
        <div class = "title-section"></div>
            
            <!-- Producto 2  -->
            <div class = "row">
                <div class="col-sm-2 card card-body" style="text-align: center">         
                    <div class = "product-box">
                        <div class = "product">
                        <img src=<?php echo e($product -> imgUrl); ?> width = "200" height = "300"></img>
                        <div class = "title"><?php echo e($product -> name); ?></div>
                        <div class = "description"><?php echo e($product -> description); ?></div>
                        <?php if($product -> discountPercent > 0): ?>
                            <div class = "price"><?php echo e(round($product -> price * (1 - $product -> discountPercent / 100), 2)); ?>€</div>
                        <?php else: ?>
                            <div class = "price"><?php echo e($product -> price); ?>$</div>
                        <?php endif; ?>
                        </div>
                    </div>
                    <a  type ="button" href="<?php echo e(route('cart.add',$product->id)); ?>" class="btn btn-primary">Añadir al carrito</a>
                </div>



                
            </div>

            
            <?php $__env->startSection('content-right'); ?>
            <!-- BLOCK: RIGHT -->
            <div class="col-sm-2 sidenav"> <!-- col-sm-2 means two out of twelve columns -->
                <!-- SECTION: Cards -->
                <div class = "title-section">Más vendidos</div>
                <div class="card card-body bg-faded" style="background-color: #ffbc6a">
            
                <div class = "product-box">
                <a href = "./Ofertas">
                    <div class = "product">
                    <img src="/img/onepiece.jpg"
                    width = "150" height = "200" />
                    <div class = "title">One Piece</div>
                    <div class = "description">Tomo 6</div>
                    <div class = "price"> 7.<span>99€</span></div>
                    </div>    
                </a>
                </div>
            

            
                    
                <div class = "product-box">
                <a href = "./Ofertas">
                    <div class = "product">
                    <img src="/img/dragonball.jpg"
                    width = "150" height = "200" />
                    <div class = "title">Dragon Ball</div>
                    <div class = "description">Tomo 7</div>
                    <div class = "price"> 7.<span>99€</span></div>
                    </div>    
                </a>
                </div>
            </div>
        </div>                  
    </div>
    <?php $__env->stopSection(); ?>
</div>
                      

<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ine22xxx\resources\views/product/show.blade.php ENDPATH**/ ?>