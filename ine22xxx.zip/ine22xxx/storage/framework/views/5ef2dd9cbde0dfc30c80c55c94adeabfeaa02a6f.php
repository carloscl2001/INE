
 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php $__env->startSection('content-center'); ?>

<div class="row">
        

        <!-- BLOCK: CENTER -->
        <div class="col-sm-10"> <!-- col-sm-7 means seven out of twelve columns -->                     
        
            
            
        </div>   

    <div class="container-fluid" style="margin-top:30px">
    <div class="row">
        

        <!-- BLOCK: CENTER -->
        <div class="col-sm-10"> <!-- col-sm-7 means seven out of twelve columns -->                     
        
            
        <div class = "title-section"></div>
            
            <!-- Producto 2  -->
            <div class = "row">
                <div class="col-sm-2 card card-body" style="text-align: center">         
                <?php $__currentLoopData = session()->get('cart')->htItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <div class = "product-box">
                <a href = "./Ofertas">
                    <div class = "product">
                    <img src=<?php echo e($item['imgUrl']); ?> width = "200" height = "300"></img>
                    <div class = "title"><?php echo e($item['name']); ?></div>
                    
                    <?php if($item['discountPercent'] > 0): ?>
                            <div class = "price"><?php echo e(round($item['price'] - $item['price']*($item['discountPercent']/100),2)); ?>€</div>
                        <?php else: ?>
                            <div class = "price"><?php echo e($item['price']); ?>$</div>
                        <?php endif; ?>
                    </div>    
                </a>
                </div>

                <div class="col-sm-4">
                <p>Cantidad: <?php echo e($item['quantity']); ?></p>
                <a href="<?php echo e(route('cart.operate', [ 'operation' => 'add', 'product' => \App\Models\Product::find($item['id'])])); ?>" class="btn btn-success">+</a>
                <a href="<?php echo e(route('cart.operate', [ 'operation' => 'remove', 'product' => \App\Models\Product::find($item['id'])])); ?>" class="btn btn-danger">-</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($item)): ?>
                <p>Productos totales: <?php echo e(session()->get('cart')->itotalItems); ?></p>
                <p>Precio total: <?php echo e(session()->get('cart')->dTotalPrice); ?> €</p>
                <a href=" <?php echo e(route('cart.operate', [ 'operation' => 'removeAll', 'product' => \App\Models\Product::find($item['id'])])); ?>" class="btn btn-danger">Vaciar carrito</a>
                <?php else: ?>
                <p>El carrito está vacío</p>
                <?php endif; ?>
            </div>
                </div>



                
            </div>
        </div>                  
    </div>
</div>
                      

<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ine22xxx\resources\views/cart/show.blade.php ENDPATH**/ ?>