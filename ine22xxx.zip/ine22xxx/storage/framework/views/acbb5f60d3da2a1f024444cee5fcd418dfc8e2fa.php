
<?php $__env->startSection('content-center'); ?>
<?php if(session()->has('success')): ?>
 <div class="alert alert-success">
 <?php echo e(session()->get('success', null)[0]); ?>

 </div>
 <?php endif; ?>
 
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="alert alert-warning"><?php echo e($sError); ?></div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <div class="card">
 <div class="card-header text-center font-weight-bold">
 Datos de usuario
 </div>
 <div class="card-body">
 <form name="edit-user-form" id="edit-user-form" 
 action="<?php echo e(route('user.update')); ?>" method="post">
 <?php echo method_field('PATCH'); ?>
 <?php echo csrf_field(); ?>
 <div class="form-group">
 <label for="email"><?php echo e(__('auth.Email')); ?></label>
 <input type="text" id="email" name="email" disabled="" 
 value="<?php echo e(Auth::user()->email); ?>" />
 <br/>
 <label for="name"><?php echo e(__('auth.Name')); ?></label>
 <input type="text" id="name" name="name" 
 class="form-control" required="" 
 value="<?php echo e(Auth::user()->name); ?>" />
 <label for="oldPass"><?php echo e(__('auth.Old password')); ?></label>
 <input type="password" id="oldPass" name="oldPass"
 class="form-control" />
 <label for="newPass"><?php echo e(__('auth.New password')); ?></label>
 <input type="password" id="newPass" name="newPass" 
 class="form-control" />
 <label for="repeatedPass"><?php echo e(__('auth.Repeat password')); ?>

 </label>
 <input type="password" id="repeatedPass" name="repeatedPass"
 class="form-control" />
 </div>
 <button type="submit" class="btn btn-primary"><?php echo e(__('auth.Save')); ?></button>
 </form>
 </div>
 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ine22xxx\resources\views/user/edit.blade.php ENDPATH**/ ?>