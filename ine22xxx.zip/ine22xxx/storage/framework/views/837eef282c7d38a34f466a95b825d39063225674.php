<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('Dx30T53')) {
    $componentId = $_instance->getRenderedChildComponentId('Dx30T53');
    $componentTag = $_instance->getRenderedChildComponentTagName('Dx30T53');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Dx30T53');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('Dx30T53', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\ine22xxx\vendor\livewire\livewire\src\Testing/../views/mount-component.blade.php ENDPATH**/ ?>