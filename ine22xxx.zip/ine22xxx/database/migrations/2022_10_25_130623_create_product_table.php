<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Products', function (Blueprint $table) {
            $table->id();
            $table->string('name', 256);
            $table->longText('description', 256);
            $table->string('imgUrl', 256)->nullable(true)->unique();
            $table->decimal('price')->nullable(false);
            $table->decimal('discountPercent');
            $table->integer('quantity')->nullable(false);
            $table->date('discountStart_at', 256)->nullable(true);
            $table->date('discountEnd_at', 256)->nullable(true);
            $table->date('datetime', 256)->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Products');
    }
};
