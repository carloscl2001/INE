<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;  

class Cart extends Model
{
    use HasFactory;

    public $iTotalItems;

    public $dTotalPrice;

    public $htItem = [];

    function __construct(Cart $cart = null){
        if($cart != null){
            $this->htItem = $cart->htItem;
            $this->iTotalItems = $cart->iTotalItems;
            $this->iTotalPrice = $cart->iTotalPrice;
        }
    }
    

    public function add(Product $producto){
        if(array_key_exists($producto->id, $this->htItem))
            $this->htItem[$producto->id]['quantity']++;
        else{
            $this->htItem[$producto->id]['quantity'] = 1;
            $this->htItem[$producto->id]['price'] = $producto->price;
            $this->htItem[$producto->id]['discountPercent'] = $producto->discountPercent;
            $this->htItem[$producto->id]['name'] = $producto->name;
            $this->htItem[$producto->id]['imgUrl'] = $producto->imgUrl;
            $this->htItem[$producto->id]['id'] = $producto->id;
        }
        $this->itotalItems++;
        if($producto->discountPercent > 0){
            $this->dTotalPrice += round($producto->price - $producto->price*($producto->discountPercent/100),2);
        }
        else{
            $this->dTotalPrice += $producto->price;
        }
        
    }

    public function remove(Product $product){
        if(array_key_exists($product->id, $this->htItem)){
            if($this->htItem[$product->id]['quantity'] > 0){
                $this->htItem[$product->id]['quantity']--;
                $this->itotalItems--;
                $this->dTotalPrice -= $product->price;
            }
        }
        if($this->dTotalPrice <= 0){
            $this->htItem = [];
            $this->itotalItems = 0;
            $this->dTotalPrice = 0;
        }
    }

    public function removeAll(Product $product)
    {
        if(array_key_exists($product->id, $this->htItem)) {
            $this->iTotalItems -= $this->htItem[$product->id]['quantity'];
            $this->dTotalPrice -= $this->htItem[$product->id]['quantity'] * $product->price;
            unset($this->htItem[$product->id]);
        }
    }
}
