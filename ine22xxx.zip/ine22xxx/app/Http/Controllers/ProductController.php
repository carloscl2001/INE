<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use GrahamCampbell\ResultType\Success;

class ProductController extends Controller
{
    static function welcome(){
        $aProduct_offering = \App\Models\Product::Offerings();
        $aProduct_new = \App\Models\Product::NewProducts();
       
        
        return view('welcome', compact('aProduct_offering', 'aProduct_new'));
    }

    public function show(Product $product){
        #$product = \App\Models\Product::find($product);
        #dd($product);
        return view('product.show', compact('product'));
    }

    public function addToCart(Product $product, Request $request){
        $cart = $request->session()->get('cart');
        if(!$cart){
            $cart = new \App\Models\Cart();
        }
        $cart->add($product);
        $request->session()->put('cart', $cart);
        $success = "Producto añadido al carrito";
        return view('product/show',compact('product','success'));
    }

    public function update(Product $product, Request $request){
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->stock = $request->stock;
        $product->company = $request->company;
        $product->save();
        $success = "Producto actualizado";
        return view('product/show',compact('product','success'));
    }

    public function edit(Product $product){
        $aCompany = \App\Models\Company::all();
        return view('product.edit', compact('product', 'aCompany'));
    }
}